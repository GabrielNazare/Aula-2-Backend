const express = require ("express");
const app = express();

app.use(express.json());

app.get("/", function (req, res){
    res.send('<a href="/teste">Sobre</a>');
});

app.get("/teste", function (req, res){
    res.send("Olá mundo");
});

const lista = ["Gabriel", "Isa"];

app.get("/nomes", function (req, res){
    res.send(lista);
});

app.post("/nomes", function (req, res){
    const item = req.body.nome;
    lista.push(item);
    res.send("Item criado com sucesso");
});

app.get("/nomes/:id", function (req, res){
    const id = req.params.id -1;
    const item = lista[id];
    res.send(item);
});

app.put("/nomes/:id", function (req, res){
    const id = req.params.id - 1;
    const item = req.body.nome;
    lista[id] = item;
    res.send("Item editado com sucesso!");
});

app.delete("/nomes/:id", function (req, res){
    res.send("Item excluido com sucesso");
});

app.listen(3000);