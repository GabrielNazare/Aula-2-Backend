const express = require('express');
const app = express();

// Rota para a página principal
app.get('/', function (req, res) {
    res.send(`
        <h1>Bem-vindo ao Nosso Site!</h1>
        <p>Este é um exemplo simples de site com Express em Node.js.</p>
        <a href="/sobre">Sobre</a> | <a href="/contato">Contato</a>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1 { color: navy; }
            a { color: darkred; }
        </style>
    `);
});

// Rota para a página Sobre
app.get('/sobre', function (req, res) {
    res.send(`
        <h1>Sobre Nós</h1>
        <p>Somos uma empresa fictícia criada para demonstrar como construir um site simples com Express.</p>
        <a href="/">Home</a> | <a href="/contato">Contato</a>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1 { color: green; }
            a { color: darkred; }
        </style>
    `);
});

// Rota para a página Contato
app.get('/contato', function (req, res) {
    res.send(`
        <h1>Contato</h1>
        <p>Entre em contato conosco pelo e-mail <a href="mailto:contato@exemplo.com">contato@exemplo.com</a>.</p>
        <a href="/">Home</a> | <a href="/sobre">Sobre</a>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1 { color: red; }
            a { color: darkred; }
        </style>
    `);
});

// Configurando o servidor para ouvir na porta 3000
app.listen(3000, function () {
    console.log('Servidor rodando na porta 3000');
});
